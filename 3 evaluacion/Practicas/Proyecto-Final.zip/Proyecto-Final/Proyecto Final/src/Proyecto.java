//import static jNetpcap.Captura.filtro;
//import static jNetpcap.Captura.l;
//import static jNetpcap.Captura.lo;
//import static jNetpcap.Captura.op;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.jnetpcap.JBufferHandler;
import org.jnetpcap.Pcap;
import org.jnetpcap.PcapBpfProgram;
import org.jnetpcap.PcapDumper;
import org.jnetpcap.PcapHandler;
import org.jnetpcap.PcapHeader;
import org.jnetpcap.PcapIf;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;

public class Proyecto extends javax.swing.JFrame implements Runnable{
    public static Scanner l = new Scanner(System.in);
    int cont=0;
    private static String asString(final byte[] mac) {
        final StringBuilder buf = new StringBuilder();
        for (byte b : mac) {
            if (buf.length() != 0) {
                buf.append(':');
            }
            if (b >= 0 && b < 16) {
                buf.append('0');
            }
            buf.append(Integer.toHexString((b < 0) ? b + 256 : b).toUpperCase());
        }
        return buf.toString();
    }

    Pcap pcap=null;
    List<PcapIf> alldevs = new ArrayList<PcapIf>();
    StringBuilder errbuf = new StringBuilder();
    String dispositivos[];
    Thread t;
    int a;
    
    double ieee = 0;
    double ethernet = 0;
    
    double ipv4 = 0;
    double ipv6 = 0;
    double ethertalk = 0;
    double aarp = 0;
    double arp = 0;
    double desconocido = 0;
    
    double udp = 0;
    double tcp = 0;
    
    public Proyecto() {
        initComponents();
        
        filtro.setVisible(false);
        
        jComboBox1.setVisible(false);
        jLabel1.setVisible(false);
        jLabel3.setVisible(false);
        leer.setVisible(false);
        pack.setVisible(false);
        ini.setVisible(false);
        info.setVisible(false);
        detener.setVisible(false);
        jButton1.setVisible(false);
        graficas.setVisible(false);
        
        
        int r = Pcap.findAllDevs(alldevs, errbuf);
        if (r == Pcap.NOT_OK || alldevs.isEmpty()) {
            System.err.printf("Can't read list of devices, error is %s", errbuf.toString());
            return;
        }


        int i = 0;

        try{
            for (PcapIf device : alldevs) {
                String description = (device.getDescription() != null) ? device.getDescription() : "No description available";
                final byte[] mac = device.getHardwareAddress();
                String dir_mac = (mac==null)?"No tiene direccion MAC":asString(mac);
                jComboBox1.addItem(""+i+++": "+device.getName()+" ["+description+"] MAC: ["+dir_mac+"]");
            }

            dispositivos = new String[++i];

            for(int d = 0; d < i; d++){
                dispositivos[d] = jComboBox1.getItemAt(d);
            }
        }
        catch(Exception e){
            
        }
    }

    
    public void run(){
                
        PcapPacketHandler<String> jpacketHandler = new PcapPacketHandler<String>() {

            public void nextPacket(PcapPacket packet, String user) {

                    /*System.out.printf("\n\nPaquete recibido el %s \n\tcaplen=%-4d \n\tlongitud=%-4d %s\n\n",
                        new Date(packet.getCaptureHeader().timestampInMillis()),
                        packet.getCaptureHeader().caplen(),  // Length actually captured
                        packet.getCaptureHeader().wirelen(), // Original length
                        user                                 // User supplied object
                        );*/
                    info.append(String.format("\n\nPaquete recibido el %s \n\tCaplen: %-4d \n\tLongitud: %-4d %s\n\n",
                        new Date(packet.getCaptureHeader().timestampInMillis()),
                        packet.getCaptureHeader().caplen(),  // Length actually captured
                        packet.getCaptureHeader().wirelen(), // Original length
                        user));


                    /******Desencapsulado********/
                    for(int i=0;i<packet.size();i++){
                        //System.out.printf("%02X ",packet.getUByte(i));
                        info.append(String.format("%02X ",packet.getUByte(i)));

                        if(i%16==15){
                            //System.out.println("");
                            info.append("\n");
                        }
                    }//if

                    int te, tipo, hw, proto, ope, control, codigo, nr, ns, ver;
                    int longitud = (packet.getUByte(12)*256)+packet.getUByte(13);

                    if(longitud<1500){
                        ieee++;
                        /*System.out.println("\n\tCAPA DE ENLACE DE DATOS\n \t\tTrama IEEE802.3");
                        System.out.printf("\n \t\tMAC Destino: %02X", packet.getUByte(0));*/
                        
                        info.append("\n\tCAPA DE ENLACE DE DATOS\n \t\tTrama IEEE802.3");
                        info.append(String.format("\n \t\tMAC Destino: %02X", packet.getUByte(0)));
                        
                        for(int p = 1; p<=5; p++){
                            //System.out.printf(":%02X", packet.getUByte(p));
                            info.append(String.format(":%02X", packet.getUByte(p)));
                        }
                        //System.out.printf("\n \t\tMAC Origen: %02X",packet.getUByte(6));
                        info.append(String.format("\n \t\tMAC Origen: %02X",packet.getUByte(6)));
                        for(int p = 7; p<=11; p++){
                            //System.out.printf(":%02X", packet.getUByte(p));
                            info.append(String.format(":%02X", packet.getUByte(p)));
                        }
                        //System.out.printf("\n \t\tLongitud: %d (%04X)", longitud, longitud);
                        //System.out.printf("\n \t\tDSAP: %02X",packet.getUByte(14));
                        //System.out.printf("\n \t\tSSAP: %02X",packet.getUByte(15));
                        info.append(String.format("\n \t\tLongitud: %d (%04X)", longitud, longitud));
                        info.append(String.format("\n \t\tDSAP: %02X",packet.getUByte(14)));
                        info.append(String.format("\n \t\tSSAP: %02X",packet.getUByte(15)));

                        tipo = packet.getUByte(16) & 0x00000003;
                        int pf = packet.getUByte(17) & 0x00000001;


                        switch(tipo){
                            case 0: case 2: if(longitud > 3){
                                        control = (packet.getUByte(16)*256)+packet.getUByte(17);
                                        //System.out.printf("\n \t\tControl: %04X", control);
                                        //System.out.printf("\n \t\tTipo: Información (Extendido)");
                                        info.append(String.format("\n \t\tControl: %04X", control));
                                        info.append("\n \t\tTipo: Información (Extendido)");
                                        
                                        
                                        ns = packet.getUByte(16) & 0x000000FF;
                                        ns = ns>>1;
                                        //System.out.printf("\n \t\tN(S): %d", ns);
                                        info.append(String.format("\n \t\tN(S): %d", ns));
                                        nr = packet.getUByte(17) & 0x000000FE;
                                        nr = nr>>1;
                                        //System.out.printf("\n \t\tN(R): %d", nr);
                                        info.append(String.format("\n \t\tN(R): %d", nr));
                                    }
                                    else{
                                        control = packet.getUByte(16);
                                        //System.out.printf("\n \t\tControl: %02X", control);
                                        //System.out.printf("\n \t\tTipo: Información");
                                        info.append(String.format("\n \t\tControl: %02X", control));
                                        info.append("\n \t\tTipo: Información");
                                        
                                        ns = packet.getUByte(16) & 0x0000000F;
                                        //System.out.printf("\n \t\tN(S): %d", ns>>1);
                                        info.append(String.format("\n \t\tN(S): %d", ns>>1));
                                        nr = packet.getUByte(16) & 0x000000E0;
                                        //System.out.printf("\n \t\tN(R): %d", nr>>1);
                                        info.append(String.format("\n \t\tN(R): %d", nr>>1));
                                    }

                                    if(pf == 1){
                                        pf = packet.getUByte(15) & 0x00000001;
                                        if(pf == 1){
                                            //System.out.printf("\n \t\tP/F: Encendido (R)");
                                            info.append("\n \t\tP/F: Encendido (R)");
                                        }
                                        else{
                                            //System.out.printf("\n \t\tP/F: Encendido (C)");
                                            info.append("\n \t\tP/F: Encendido (C)");
                                        }
                                    }
                                    else{
                                        //System.out.printf("\n \t\tP/F: Apagado");
                                        info.append("\n \t\tP/F: Apagado");
                                    }

                                    break;
                            case 1: if(longitud > 3){
                                        control = (packet.getUByte(16)*256)+packet.getUByte(17);
                                        //System.out.printf("\n \t\tControl: %04X", control);
                                        //System.out.printf("\n \t\tTipo: Secuencia (Extendido)");
                                        info.append(String.format("\n \t\tControl: %04X", control));
                                        info.append("\n \t\tTipo: Secuencia (Extendido)");
                                        
                                        codigo = packet.getUByte(16) & 0x0000000D;
                                        switch(codigo){
                                            case    1:  //System.out.printf("\n \t\tCodigo: RR");
                                            info.append("\n \t\tCodigo: RR");
                                                        break; 
                                            case    5:  //System.out.printf("\n \t\tCodigo: RNR");
                                            info.append("\n \t\tCodigo: RNR");
                                                        break;
                                            case    9:  //System.out.printf("\n \t\tCodigo: REJ");
                                            info.append("\n \t\tCodigo: REJ");
                                                        break;
                                            default:    //System.out.printf("\n \t\tCodigo: SRET");
                                            info.append("\n \t\tCodigo: SRET");
                                                        break;
                                        }
                                        nr = packet.getUByte(17) & 0x000000FE;
                                        //System.out.printf("\n \t\tN(R): %d", nr>>1);
                                        info.append(String.format("\n \t\tN(R): %d", nr>>1));
                                    }
                                    else{
                                        control = packet.getUByte(16);
                                        //System.out.printf("\n \t\tControl: %02X", control);
                                        //System.out.printf("\n \t\tTipo: Secuencia");
                                        info.append(String.format("\n \t\tControl: %02X", control));
                                        info.append("\n \t\tTipo: Secuencia");
                                        
                                        codigo = packet.getUByte(16) & 0x0000000D;
                                        switch(codigo){
                                            case    1:  //System.out.printf("\n \t\tCodigo: RR");
                                            info.append("\n \t\tCodigo: RR");
                                                        break; 
                                            case    5:  //System.out.printf("\n \t\tCodigo: RNR");
                                            info.append("\n \t\tCodigo: RNR");
                                                        break;
                                            case    9:  //System.out.printf("\n \t\tCodigo: REJ");
                                            info.append("\n \t\tCodigo: REJ");
                                                        break;
                                            default:    //System.out.printf("\n \t\tCodigo: SRET");
                                            info.append("\n \t\tCodigo: SRET");
                                                        break;
                                        }
                                        nr = packet.getUByte(16) & 0x000000E0;
                                        nr = nr>>1;
                                        //System.out.printf("\n \t\tN(R): %d", nr);
                                        info.append(String.format("\n \t\tN(R): %d", nr));
                                    }

                                    if(pf == 1){
                                        pf = packet.getUByte(15) & 0x00000001;
                                        if(pf == 1){
                                          //  System.out.printf("\n \t\tP/F: Encendido (R)");
                                            info.append("\n \t\tP/F: Encendido (R)");
                                        }
                                        else{
                                            //System.out.printf("\n \t\tP/F: Encendido (C)");
                                            info.append("\n \t\tP/F: Encendido (C)");
                                        }

                                    }
                                    else{
                                        //System.out.printf("\n \t\tP/F: Apagado");
                                        info.append("\n \t\tP/F: Apagado");
                                    }

                                    break;
                            case 3: control = packet.getUByte(16);
                                    //System.out.printf("\n \t\tControl: %02X", control);
                                    //System.out.printf("\n \t\tTipo: Trama no numerada");
                                    info.append(String.format("\n \t\tControl: %02X", control));
                                    info.append("\n \t\tTipo: Trama no numerada");
                                    
                                    codigo = control & 0x000000EF;
                                    switch(codigo){
                                        case    111:    //System.out.printf("\n \t\tCodigo: SABME");
                                        info.append("\n \t\tCodigo: SABME");
                                                        break;
                                        case    99:     //System.out.printf("\n \t\tCodigo: UA");
                                        info.append("\n \t\tCodigo: UA");
                                                        break;
                                        case    175:    //System.out.printf("\n \t\tCodigo: XID");
                                        info.append("\n \t\tCodigo: XID");
                                                        break;
                                        case    67:     //System.out.printf("\n \t\tCodigo: DISC");
                                        info.append("\n \t\tCodigo: DISC");
                                                        break;
                                        case    3:      //System.out.printf("\n \t\tCodigo: UI");
                                        info.append("\n \t\tCodigo: UI");
                                                        break;
                                        case    143:    //System.out.printf("\n \t\tCodigo: RSET");
                                        info.append("\n \t\tCodigo: RSET");
                                                        break;
                                        default:        //System.out.printf("\n \t\tCodigo: Sin idfentificar");
                                        info.append("\n \t\tCodigo: Sin identificar");
                                                        break;
                                    }
                                    pf = control & 0x00000010;
                                    if(pf == 16){
                                        pf = packet.getUByte(15) & 0x00000001;
                                        if(pf == 1){
                                            //System.out.printf("\n \t\tP/F: Encendido (R)");
                                            info.append("\n \t\tP/F: Encendido (R)");
                                        }
                                        else{
                                            //System.out.printf("\n \t\tP/F: Encendido (C)");
                                            info.append("\n \t\tP/F: Encendido (C)");
                                        }
                                    }
                                    else{
                                        //System.out.printf("\n \t\tP/F: Apagado");
                                        info.append("\n \t\tP/F: Apagado");
                                    }

                                    break;
                            default: break;
                        }


                    } else if(longitud>=1500){
                        ethernet++;
                        //System.out.println("\n\tCAPA DE ENLACE DE DATOS\n \t\tTrama Ethernet");
                        //System.out.printf(" \t\tMAC Destino: %02X", packet.getUByte(0));
                        info.append("\n\tCAPA DE ENLACE DE DATOS\n \t\tTrama Ethernet");
                        info.append(String.format("\n \t\tMAC Destino: %02X", packet.getUByte(0)));
                        

                        for(int p = 1; p<=5; p++){
                            //System.out.printf(":%02X", packet.getUByte(p));
                            info.append(String.format(":%02X", packet.getUByte(p)));
                        }

                        //System.out.printf("\n \tMAC Origen: %02X",packet.getUByte(6));
                        info.append(String.format("\n \t\tMAC Origen: %02X",packet.getUByte(6)));

                        for(int p = 7; p<=11; p++){
                            //System.out.printf(":%02X", packet.getUByte(p));
                            info.append(String.format(":%02X", packet.getUByte(p)));
                        }

                        //System.out.printf("\n \t\tTipo: %02X %02X",packet.getUByte(12), packet.getUByte(13));
                        info.append(String.format("\n \t\tTipo: %02X %02X",packet.getUByte(12), packet.getUByte(13)));

                        tipo = (packet.getUByte(12)*256) + packet.getUByte(13);

                        switch(tipo){

                            case    2048:   ipv4++;
                                            System.out.printf(" Internet Protocol version 4 (IPv4) (");
                                            System.out.printf(ipv4+")\n");
                                            info.append(" Internet Protocol version 4 (IPv4)");
                                            info.append("\n\tCAPA DE RED\n");
                                            
                                            ver = packet.getUByte(14)>>4;
                                            //System.out.printf(" \t\tVersion: %d", ver);
                                            info.append(String.format(" \t\tVersion: %d", ver));
                                            
                                            te = packet.getUByte(14) & 0x0000000F;
                                            //System.out.printf("\n \t\tTamaño encabezado: %d (%d bytes)", te, te*4);
                                            //System.out.printf("\n \t\tTipo de servicio: %02X", packet.getUByte(15));
                                            //System.out.printf("\n \t\tLongitud total del paquete: %d", ((packet.getUByte(16)<<8)+packet.getUByte(17)));
                                            //System.out.printf("\n \t\tIdentificación: %d", ((packet.getUByte(18)<<8)+packet.getUByte(19)));
                                            //System.out.printf("\n \t\tBanderas: %02X", packet.getUByte(20));
                                            //System.out.printf("\n \t\tOffset: %d", packet.getUByte(21));
                                            //System.out.printf("\n \t\tTime to Live: %d", packet.getUByte(22));
                                            //System.out.printf("\n \t\tProtocolo: %02X (%d)", packet.getUByte(23), packet.getUByte(23));
                                            //System.out.printf("\n \t\tChecksum: %02X %02X", packet.getUByte(24), packet.getUByte(25));
                                            //System.out.printf("\n \t\tDirección origen: %d.%d.%d.%d", packet.getUByte(26), packet.getUByte(27), packet.getUByte(28), packet.getUByte(29));
                                            //System.out.printf("\n \t\tDirección destino: %d.%d.%d.%d", packet.getUByte(30), packet.getUByte(31), packet.getUByte(32), packet.getUByte(33));
                                            
                                            info.append(String.format("\n \t\tTamaño encabezado: %d (%d bytes)", te, te*4));
                                            info.append(String.format("\n \t\tTipo de servicio: %02X", packet.getUByte(15)));
                                            info.append(String.format("\n \t\tLongitud total del paquete: %d", ((packet.getUByte(16)<<8)+packet.getUByte(17))));
                                            info.append(String.format("\n \t\tIdentificación: %d", ((packet.getUByte(18)<<8)+packet.getUByte(19))));
                                            info.append(String.format("\n \t\tBanderas: %02X", packet.getUByte(20)));
                                            info.append(String.format("\n \t\tOffset: %d", packet.getUByte(21)));
                                            info.append(String.format("\n \t\tTime to Live: %d", packet.getUByte(22)));
                                            info.append(String.format("\n \t\tProtocolo: %02X (%d)", packet.getUByte(23), packet.getUByte(23)));
                                            info.append(String.format("\n \t\tChecksum: %02X %02X", packet.getUByte(24), packet.getUByte(25)));
                                            info.append(String.format("\n \t\tDirección origen: %d.%d.%d.%d", packet.getUByte(26), packet.getUByte(27), packet.getUByte(28), packet.getUByte(29)));
                                            info.append(String.format("\n \t\tDirección destino: %d.%d.%d.%d", packet.getUByte(30), packet.getUByte(31), packet.getUByte(32), packet.getUByte(33)));
                                            
                                            if(packet.getUByte(23) == 6){
                                                tcp++;
                                                System.out.printf("\n\tCAPA DE TRANSPORTE (TCP) (");
                                                System.out.printf(tcp+")\n");
                                                //System.out.printf("\n \t\tPuerto destino: %d", ((packet.getUByte(36)<<8)+packet.getUByte(37)));
                                                info.append("\n\tCAPA DE TRANSPORTE (TCP)");
                                                info.append(String.format("\n \t\tPuerto origen: %d", ((packet.getUByte(34)<<8)+packet.getUByte(35))));
                                                info.append(String.format("\n \t\tPuerto destino: %d", ((packet.getUByte(36)<<8)+packet.getUByte(37))));
                                                
                                                float sec = 0, acu = 0;

                                                sec=packet.getUByte(38);
                                                sec*=256;
                                                sec+=packet.getUByte(39);
                                                sec*=256;
                                                sec+=packet.getUByte(40);
                                                sec*=256;
                                                sec+=packet.getUByte(41);

                                                acu=packet.getUByte(42);
                                                acu*=256;
                                                acu+=packet.getUByte(43);
                                                acu*=256;
                                                acu+=packet.getUByte(44);
                                                acu*=256;
                                                acu+=packet.getUByte(45);


                                                //System.out.printf("\n \t\tNúmero de secuencia: %.0f (0x%02X%02X%02X%02X)", sec, packet.getUByte(38), packet.getUByte(39), packet.getUByte(40), packet.getUByte(41));
                                                //System.out.printf("\n \t\tNúmero de acuse: %.0f (0x%02X%02X%02X%02X)", acu, packet.getUByte(42), packet.getUByte(43), packet.getUByte(44), packet.getUByte(45));
                                                //System.out.printf("\n \t\tLongitud del encabezado: %d bytes", (packet.getUByte(46)>>4)*4);
                                                //System.out.printf("\n \t\tBanderas: 0x%02X", packet.getUByte(47));
                                                //System.out.printf("\n \t\tTamaño de ventana: %d (0x%02X%02X)", packet.getUByte(48)*256 + packet.getUByte(49), packet.getUByte(48), packet.getUByte(49));
                                                //System.out.printf("\n \t\tChecksum: 0x%02X%02X", packet.getUByte(50), packet.getUByte(51));
                                                
                                                info.append(String.format("\n \t\tNúmero de secuencia: %.0f (0x%02X%02X%02X%02X)", sec, packet.getUByte(38), packet.getUByte(39), packet.getUByte(40), packet.getUByte(41)));
                                                info.append(String.format("\n \t\tNúmero de acuse: %.0f (0x%02X%02X%02X%02X)", acu, packet.getUByte(42), packet.getUByte(43), packet.getUByte(44), packet.getUByte(45)));
                                                info.append(String.format("\n \t\tLongitud del encabezado: %d bytes", (packet.getUByte(46)>>4)*4));
                                                info.append(String.format("\n \t\tBanderas: 0x%02X", packet.getUByte(47)));
                                                info.append(String.format("\n \t\tTamaño de ventana: %d (0x%02X%02X)", packet.getUByte(48)*256 + packet.getUByte(49), packet.getUByte(48), packet.getUByte(49)));
                                                info.append(String.format("\n \t\tChecksum: 0x%02X%02X", packet.getUByte(50), packet.getUByte(51)));
                                            }
                                            else{
                                                udp++;
                                                System.out.printf("\n\tCAPA DE TRANSPORTE (UDP) (");
                                                System.out.printf(udp+")\n");
                                                //System.out.printf("\n \t\tPuerto destino: %d", ((packet.getUByte(36)<<8)+packet.getUByte(37)));
                                                //System.out.printf("\n \t\tLongitud: %d", ((packet.getUByte(38)<<8)+packet.getUByte(39)));
                                                //System.out.printf("\n \t\tChecksum: %02X %02X", packet.getUByte(40), packet.getUByte(41));
                                                
                                                info.append("\n\tCAPA DE TRANSPORTE (UDP)");
                                                info.append(String.format("\n \t\tPuerto origen: %d", ((packet.getUByte(34)<<8)+packet.getUByte(35))));
                                                info.append(String.format("\n \t\tPuerto destino: %d", ((packet.getUByte(36)<<8)+packet.getUByte(37))));
                                                info.append(String.format("\n \t\tLongitud: %d", ((packet.getUByte(38)<<8)+packet.getUByte(39))));
                                                info.append(String.format("\n \t\tChecksum: %02X %02X", packet.getUByte(40), packet.getUByte(41)));
                                            }
                                            break;
                            case    2054:   arp++;
                                            System.out.printf(" Address Resolution Protocol (ARP) (");
                                            System.out.printf(arp+")\n");
                                            info.append(" Address Resolution Protocol (ARP)");
                                            info.append(String.format("\n \t\tHardware: %02X %02X",packet.getUByte(14), packet.getUByte(15)));
                                            
                                            hw = (packet.getUByte(14)*256) + packet.getUByte(15);
                                            switch(hw){
                                                case    1:  //System.out.printf(" Ethernet (10Mb)");
                                                info.append(" Ethernet (10Mb)");
                                                            break;
                                                case    2:  //System.out.printf(" Experimental Ethernet (3Mb)");
                                                info.append(" Experimental Ethernet (3Mb)");
                                                            break;
                                                case    18: //System.out.printf(" Fibre Channel");
                                                info.append(" Fibre Channel");
                                                            break;
                                                case    20: //System.out.printf(" Serial Line");
                                                info.append(" Serial Line");
                                                            break;
                                                case    35: //System.out.printf(" Pure IP");
                                                info.append(" Pure IP");
                                                            break;
                                                default:    //System.out.printf(" Hardware desconocido");
                                                info.append(" Hardware desconocido");
                                                            break;

                                            }

                                            //System.out.printf("\n \t\tProtocolo: %02X %02X",packet.getUByte(16), packet.getUByte(17));
                                            info.append(String.format("\n \t\tProtocolo: %02X %02X",packet.getUByte(16), packet.getUByte(17)));
                                            proto = (packet.getUByte(16)*256) + packet.getUByte(17);

                                            switch(proto){

                                                case    2048:   //System.out.printf(" Internet Protocol version 4 (IPv4)");
                                                info.append(" Internet Protocol version 4 (IPv4)");
                                                                break;
                                                default:    //System.out.printf(" Protocolo no identificado");
                                                info.append(" Protocolo no identificado");
                                                            break;
                                            }

                                            //System.out.printf("\n \t\tTamaño hardware: %02X (%d)",packet.getUByte(18), packet.getUByte(18));
                                            //System.out.printf("\n \t\tTamaño protocolo: %02X (%d)",packet.getUByte(19), packet.getUByte(19));
                                            //System.out.printf("\n \t\tTipo operación: %02X %02X",packet.getUByte(20), packet.getUByte(21));
                                            info.append(String.format("\n \t\tTamaño hardware: %02X (%d)",packet.getUByte(18), packet.getUByte(18)));
                                            info.append(String.format("\n \t\tTamaño protocolo: %02X (%d)",packet.getUByte(19), packet.getUByte(19)));
                                            info.append(String.format("\n \t\tTipo operación: %02X %02X",packet.getUByte(20), packet.getUByte(21)));
                                            
                                            ope = (packet.getUByte(20)*256) + packet.getUByte(21);

                                            switch(ope){
                                                case    1:  //System.out.printf(" REQUEST");
                                                info.append(" REQUEST");
                                                            break;
                                                case    2:  //System.out.printf(" REPLY");
                                                info.append(" REPLY");
                                                            break;
                                            }

                                            //System.out.printf("\n \t\tMAC Origen: %02X",packet.getUByte(22));
                                            info.append(String.format("\n \t\tMAC Origen: %02X",packet.getUByte(22)));

                                            for(int p = 23; p<=27; p++){
                                                //System.out.printf(":%02X", packet.getUByte(p));
                                                info.append(String.format(":%02X", packet.getUByte(p)));
                                            }

                                            //System.out.printf("\n \t\tIP Origen: %d.%d.%d.%d", packet.getUByte(28), packet.getUByte(29), packet.getUByte(30), packet.getUByte(31));
                                            //System.out.printf("\n \t\tMAC Destino: %02X",packet.getUByte(32));
                                            info.append(String.format("\n \t\tIP Origen: %d.%d.%d.%d", packet.getUByte(28), packet.getUByte(29), packet.getUByte(30), packet.getUByte(31)));
                                            info.append(String.format("\n \t\tMAC Destino: %02X",packet.getUByte(32)));

                                            for(int p = 33; p<=37; p++){
                                                //System.out.printf(":%02X", packet.getUByte(p));
                                            }

                                            //System.out.printf("\n \t\tIP Destino: %d.%d.%d.%d", packet.getUByte(38), packet.getUByte(39), packet.getUByte(40), packet.getUByte(41));
                                            info.append(String.format("\n \t\tIP Destino: %d.%d.%d.%d", packet.getUByte(38), packet.getUByte(39), packet.getUByte(40), packet.getUByte(41)));

                                            break;
                            case    32923:  ethertalk++;
                                            System.out.printf(" AppleTalk (Ethertalk) (");
                                            System.out.printf(""+ethertalk);
                                            System.out.printf(")\n");
                            info.append(" AppleTalk (Ethertalk)");
                                            break;
                            case    33011:  aarp++;
                                            System.out.printf(" AppleTalk Address Resolution Protocol (AARP) (");
                                            System.out.printf(""+aarp);
                                            System.out.printf(")\n");
                            info.append(" AppleTalk Address Resolution Protocol (AARP)");
                            
                                            break;
                            case    34525:  ipv6++;
                                            System.out.printf(" Internet Protocol version 6 (IPv6) (");
                                            System.out.printf(""+ipv6);
                                            System.out.printf(")\n");
                            info.append(" Internet Protocol version 6 (IPv6)");
                                            break;
                            default:    desconocido++;
                                        System.out.printf(" Tipo desconocido(");
                                        System.out.printf(""+desconocido);
                                            System.out.printf(")\n");
                            info.append(" Tipo desconocido");
                                        break;
                        }
                    }//else

                    //System.out.println("\n\nEncabezado: "+ packet.toHexdump());


            }
		};


		/***************************************************************************
		 * Fourth we enter the loop and tell it to capture 10 packets. The loop
		 * method does a mapping of pcap.datalink() DLT value to JProtocol ID, which
		 * is needed by JScanner. The scanner scans the packet buffer and decodes
		 * the headers. The mapping is done automatically, although a variation on
		 * the loop method exists that allows the programmer to sepecify exactly
		 * which protocol ID to use as the data link type for this pcap interface.
		 **************************************************************************/

                if(pack.getText().equals("")){
                    pcap.loop(a, jpacketHandler, " ");
                }
                else{
                    pcap.loop(Integer.parseInt(pack.getText()), jpacketHandler, " ");
                }
		/***************************************************************************
		 * Last thing to do is close the pcap handle
		 **************************************************************************/
		pcap.close();
                       
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        graficas = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        pack = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        vuelo = new javax.swing.JButton();
        archivo = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        filtro = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        info = new javax.swing.JTextArea();
        leer = new javax.swing.JButton();
        ini = new javax.swing.JButton();
        detener = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();

        graficas.setText("Estadísticas");
        graficas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                graficasMouseClicked(evt);
            }
        });

        jButton1.setText("Capturar a archivo");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel3.setText("No. paquetes:");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 245));

        jLabel1.setText("Ingrese su IP:");

        vuelo.setText("Capturas al vuelo");
        vuelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vueloActionPerformed(evt);
            }
        });

        archivo.setText("Captura desde archivo");
        archivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                archivoActionPerformed(evt);
            }
        });

        filtro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtroActionPerformed(evt);
            }
        });

        info.setEditable(false);
        info.setBackground(new java.awt.Color(0, 0, 0));
        info.setColumns(20);
        info.setForeground(new java.awt.Color(35, 209, 44));
        info.setRows(5);
        jScrollPane1.setViewportView(info);

        leer.setText("Abrir Archivo");
        leer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leerActionPerformed(evt);
            }
        });

        ini.setText("Iniciar Captura");
        ini.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniActionPerformed(evt);
            }
        });

        detener.setText("Detener Captura");
        detener.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                detenerMouseClicked(evt);
            }
        });
        detener.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detenerActionPerformed(evt);
            }
        });

        jLabel2.setText("Proyecto final: Alejandro Hernández Gómez - 2CM8");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(vuelo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(archivo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 468, Short.MAX_VALUE)
                        .addComponent(detener))
                    .addComponent(filtro, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(leer)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ini))
                    .addComponent(jScrollPane1)
                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(vuelo)
                    .addComponent(archivo)
                    .addComponent(detener))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(filtro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE)
                .addGap(11, 11, 11)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ini)
                    .addComponent(leer))
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void vueloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vueloActionPerformed
        InetAddress IP = null;
        try {
            IP = InetAddress.getLocalHost();
        } catch (UnknownHostException ex) {
            //Logger.getLogger(Proyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        filtro.setVisible(true);
        filtro.setText(IP.getHostAddress());
        jComboBox1.setVisible(true);
        jLabel1.setVisible(true);
        jButton1.setVisible(true);
        jLabel3.setVisible(true);
        leer.setVisible(false);
        pack.setVisible(true);
        ini.setVisible(true);
        info.setVisible(true);
        detener.setVisible(true);
        graficas.setVisible(true);
    }//GEN-LAST:event_vueloActionPerformed

    private void archivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_archivoActionPerformed
       
        filtro.setVisible(false);
        jComboBox1.setVisible(false);
        detener.setVisible(false);
        jLabel1.setVisible(false);
        
        jLabel3.setVisible(false);
        leer.setVisible(true);
        pack.setVisible(false);
        ini.setVisible(false);
        info.setVisible(true);
    }//GEN-LAST:event_archivoActionPerformed

    private void iniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniActionPerformed
        info.setText("");
        int d = 0;
        String desc;
        
        for(; d < dispositivos.length; d++){
            if(dispositivos[d].equals(jComboBox1.getSelectedItem())){
                break;
            }
        }
        
        PcapIf device = alldevs.get(d); // We know we have atleast 1 device
	
        if(device.getDescription() != null){
            desc = device.getDescription();
        }
        else{
            desc = device.getName();
        }
        
        info.append("Choosing "+desc+" on your behalf:\n");
        

        
        int snaplen = 64 * 1024;           // Capture all packets, no trucation
        int flags = Pcap.MODE_PROMISCUOUS; // capture all packets
        int timeout = 10 * 1000;           // 10 seconds in millis


        pcap = Pcap.openLive(device.getName(), snaplen, flags, timeout, errbuf);

        if (pcap == null) 
        {
                System.err.printf("Error while opening device for capture: "
                    + errbuf.toString());
                return;
        }//if

               /********F I L T R O********/
            PcapBpfProgram filter = new PcapBpfProgram();
            String expression = filtro.getText(); // "port 80";
            int optimize = 0; // 1 means true, 0 means false
            int netmask = 0;
            int r2 = pcap.compile(filter, expression, optimize, netmask);
            //if (r2 != Pcap.OK) {
                //System.out.println("Filter error: " + pcap.getErr());
                //info.append("Filter error: " + pcap.getErr());
            //}//if
            //else
            //{
            pcap.setFilter(filter);
                /****************/
           
		/***************************************************************************
		 * Third we create a packet handler which will receive packets from the
		 * libpcap loop.
		 **********************************************************************/
		
            t = new Thread(this);
            t.start();
            //}
    }//GEN-LAST:event_iniActionPerformed

    private void leerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leerActionPerformed
        info.setText("");
        try{
            /////////////////////////lee archivo//////////////////////////
            JFileChooser fileChooser = new JFileChooser(); 
      FileNameExtensionFilter extension = new FileNameExtensionFilter("archivos pcap (*.pcap)", "pcap");
            fileChooser.setFileFilter(extension);
            fileChooser.setDialogTitle("Abrir archivo");
 // set selected filter
        fileChooser.setFileFilter(extension);
      int resultado = fileChooser.showOpenDialog(null);
      if(resultado==JFileChooser.APPROVE_OPTION){
          File f = fileChooser.getSelectedFile();
          System.out.println("Archivo seleccionado: "+f.getAbsolutePath());
          String file=f.getAbsolutePath();
             pcap = Pcap.openOffline(file, errbuf);
            t = new Thread(this);
            t.start();
      }
            
         
        }
        catch(Exception e){e.printStackTrace();}
    }//GEN-LAST:event_leerActionPerformed

    private void detenerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detenerActionPerformed
        // TODO add your handling code here:
        t.interrupt();
    }//GEN-LAST:event_detenerActionPerformed

    private void detenerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_detenerMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_detenerMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        info.setText("");
        int d = 0;
        String desc;
         StringBuilder errbuf = new StringBuilder();
        
        for(; d < dispositivos.length; d++){
            if(dispositivos[d].equals(jComboBox1.getSelectedItem())){
                break;
            }
        }
        
        PcapIf device = alldevs.get(d); // We know we have atleast 1 device
	
        if(device.getDescription() != null){
            desc = device.getDescription();
        }
        else{
            desc = device.getName();
        }
        
        info.append("Choosing "+desc+" on your behalf:\n");
        

        
        int snaplen = 64 * 1024;           // Capture all packets, no trucation  
    int flags = Pcap.MODE_PROMISCUOUS; // capture all packets  
    int timeout = 10 * 1000;           // 10 seconds in millis  
    Pcap pcap = Pcap.openLive(device.getName(), snaplen, flags, timeout, errbuf);  
    if (pcap == null) {  
      System.err.printf("Error while opening device for capture: %s\n",   
        errbuf.toString());  
      return;  
    }  
          
    /*************************************************************************** 
     * Third we create a PcapDumper and associate it with the pcap capture 
     ***************************************************************************/  
    String num="-1"; //pack.getText();
    int numero=Integer.parseInt(num);
    
    String ofile = "captura.pcap";  
    PcapDumper dumper = pcap.dumpOpen(ofile); // output file  
  
    /*************************************************************************** 
     * Fouth we create a packet handler which receives packets and tells the  
     * dumper to write those packets to its output file 
     **************************************************************************/  
    PcapHandler<PcapDumper> dumpHandler = new PcapHandler<PcapDumper>() {  
  
      public void nextPacket(PcapDumper dumper, long seconds, int useconds,  
        int caplen, int len, ByteBuffer buffer) {  
  
        dumper.dump(seconds, useconds, caplen, len, buffer);  
      }  
    };  
  
    /*************************************************************************** 
     * Fifth we enter the loop and tell it to capture 10 packets. We pass 
     * in the dumper created in step 3 
     **************************************************************************/
    
    pcap.loop(numero, dumpHandler, dumper);  
          
    File file = new File(ofile);  
    info.append(ofile+" tiene "+file.length()+" bytes escritos!\n");  
          
  
    /*************************************************************************** 
     * Last thing to do is close the dumper and pcap handles 
     **************************************************************************/  
    dumper.close(); // Won't be able to delete without explicit close  
    pcap.close();  
    }//GEN-LAST:event_jButton1ActionPerformed

    private void graficasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_graficasMouseClicked
        Graficas graf = new Graficas();
        graf.setTipoTrama(ieee, ethernet); 
        graf.setProtocolo(ipv4, ipv6, ethertalk, arp, aarp, desconocido);
        graf.setProtocoloTrans(tcp, udp);
        graf.dibujarGraf();
        graf.setVisible(true);
    }//GEN-LAST:event_graficasMouseClicked

    private void filtroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filtroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filtroActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Proyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Proyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Proyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Proyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Proyecto().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton archivo;
    private javax.swing.JButton detener;
    private javax.swing.JTextField filtro;
    private javax.swing.JButton graficas;
    private javax.swing.JTextArea info;
    private javax.swing.JButton ini;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton leer;
    private javax.swing.JTextField pack;
    private javax.swing.JButton vuelo;
    // End of variables declaration//GEN-END:variables
}