//package jNetpcap;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.io.*;
import java.util.Scanner;

import org.jnetpcap.Pcap;
import org.jnetpcap.PcapAddr;
import org.jnetpcap.PcapIf;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;
import org.jnetpcap.PcapBpfProgram;
import org.jnetpcap.PcapDumper;
import org.jnetpcap.protocol.lan.Ethernet;
import org.jnetpcap.protocol.tcpip.*;
import org.jnetpcap.protocol.network.*;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.Payload;
import org.jnetpcap.protocol.network.Arp;
import org.jnetpcap.protocol.lan.IEEE802dot2;
import org.jnetpcap.protocol.lan.IEEE802dot3;


public class Captura {

	/**
	 * Main startup method
	 *
	 * @param args
	 *          ignored
	 */
    
                public static Scanner l = new Scanner(System.in);
                
                public static int op, lo;
                public static String filtro;
    
    
   private static String asString(final byte[] mac) {
    final StringBuilder buf = new StringBuilder();
    for (byte b : mac) {
      if (buf.length() != 0) {
        buf.append(':');
      }
      if (b >= 0 && b < 16) {
        buf.append('0');
      }
      buf.append(Integer.toHexString((b < 0) ? b + 256 : b).toUpperCase());
    }

    return buf.toString();
  }

	public static void main(String[] args) {
            Pcap pcap=null;
            
               try{
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));   
		List<PcapIf> alldevs = new ArrayList<PcapIf>(); // Will be filled with NICs
		StringBuilder errbuf = new StringBuilder(); // For any error msgs
                System.out.println("[0]-->Realizar captura de paquetes al vuelo");
                System.out.println("[1]-->Cargar traza de captura desde archivo");
                System.out.print("\nElige una de las opciones: ");
                int opcion = Integer.parseInt(br.readLine());
                if (opcion==1){
                    
                    /////////////////////////lee archivo//////////////////////////
                String arch;
                System.out.printf("Ingrese el nombre del archivo que desea abrir: ");
                arch = l.nextLine();
                pcap = Pcap.openOffline(arch, errbuf);
                if (pcap == null) {
                  System.err.printf("Error while opening device for capture: "+ errbuf.toString());
                  return;
                 }//if
                } else if(opcion==0){
		/***************************************************************************
		 * First get a list of devices on this system
		 **************************************************************************/
               
                int r = Pcap.findAllDevs(alldevs, errbuf);
		if (r == Pcap.NOT_OK || alldevs.isEmpty()) {
			System.err.printf("Can't read list of devices, error is %s", errbuf
			    .toString());
			return;
		}

		System.out.println("Network devices found:");

		int i = 0;
                
                try{
		for (PcapIf device : alldevs) {
			String description =
			    (device.getDescription() != null) ? device.getDescription()
			        : "No description available";
                        final byte[] mac = device.getHardwareAddress();
			String dir_mac = (mac==null)?"No tiene direccion MAC":asString(mac);
                        System.out.printf("#%d: %s [%s] MAC:[%s]\n", i++, device.getName(), description, dir_mac);

		}//for
                
                }catch(IOException e){e.printStackTrace();}
                

                
                System.out.printf("Por favor elija la interfaz en la que desea capturar.\nDispositivo: ");
                op = l.nextInt();
                
                System.out.printf("Por favor indique el número de paquetes qué desea capturar (Si desea capturar de forma indefinida tecle -1).\nNo. paquetes: ");
                lo = l.nextInt();
                l.nextLine();
                
                System.out.printf("Por favor indique si desea aplicar algun filtro a la captura (Si no desea establecer un filtro presione Enter).\nFIltros: ");
                filtro = l.nextLine();
                
                System.out.printf("%s", filtro);

		PcapIf device = alldevs.get(op); // We know we have atleast 1 device
		System.out
		    .printf("\nChoosing '%s' on your behalf:\n",
		        (device.getDescription() != null) ? device.getDescription()
		            : device.getName());

                
		/***************************************************************************
		 * Second we open up the selected device
		 **************************************************************************/
                /*"snaplen" is short for 'snapshot length', as it refers to the amount of actual data captured from each packet passing through the specified network interface.
                64*1024 = 65536 bytes; campo len en Ethernet(16 bits) tam máx de trama */

		int snaplen = 64 * 1024;           // Capture all packets, no trucation
		int flags = Pcap.MODE_PROMISCUOUS; // capture all packets
		int timeout = 10 * 1000;           // 10 seconds in millis

                
                pcap = Pcap.openLive(device.getName(), snaplen, flags, timeout, errbuf);

		if (pcap == null) {
			System.err.printf("Error while opening device for capture: "
			    + errbuf.toString());
			return;
		}//if
                  
                       /********F I L T R O********/
            PcapBpfProgram filter = new PcapBpfProgram();
            String expression =filtro; // "port 80";
            int optimize = 0; // 1 means true, 0 means false
            int netmask = 0;
            int r2 = pcap.compile(filter, expression, optimize, netmask);
            if (r2 != Pcap.OK) {
                System.out.println("Filter error: " + pcap.getErr());
            }//if
            pcap.setFilter(filter);
                /****************/
            }//else if

		/***************************************************************************
		 * Third we create a packet handler which will receive packets from the
		 * libpcap loop.
		 **********************************************************************/
		PcapPacketHandler<String> jpacketHandler = new PcapPacketHandler<String>() {

			public void nextPacket(PcapPacket packet, String user) {

				System.out.printf("\n\nPaquete recibido el %s caplen=%-4d longitud=%-4d %s\n\n",
				    new Date(packet.getCaptureHeader().timestampInMillis()),
				    packet.getCaptureHeader().caplen(),  // Length actually captured
				    packet.getCaptureHeader().wirelen(), // Original length
				    user                                 // User supplied object
				    );
                                
                                
                                /******Desencapsulado********/
                                for(int i=0;i<packet.size();i++){
                                    System.out.printf("%02X ",packet.getUByte(i));
                                
                                    if(i%16==15){
                                        System.out.println("");
                                    }
                                }//if
                                
                                int te, tipo, hw, proto, ope, control, codigo, nr, ns, ver;
                                int longitud = (packet.getUByte(12)*256)+packet.getUByte(13);
       
                                if(longitud<1500){
                                    System.out.println("\n---->CAPA DE ENLACE DE DATOS\n |-->Trama IEEE802.3");
                                    System.out.printf(" |-->MAC Destino: %02X", packet.getUByte(0));
                                    for(int p = 1; p<=5; p++){
                                        System.out.printf(":%02X", packet.getUByte(p));
                                    }
                                    System.out.printf("\n |-->MAC Origen: %02X",packet.getUByte(6));
                                    for(int p = 7; p<=11; p++){
                                        System.out.printf(":%02X", packet.getUByte(p));
                                    }
                                    System.out.printf("\n |-->Longitud: %d (%04X)", longitud, longitud);
                                    System.out.printf("\n |-->DSAP: %02X",packet.getUByte(14));
                                    System.out.printf("\n |-->SSAP: %02X",packet.getUByte(15));
                                    
                                    tipo = packet.getUByte(16) & 0x00000003;
                                    int pf = packet.getUByte(17) & 0x00000001;
                                   
                                        
                                    switch(tipo){
                                        case 0: case 2: if(longitud > 3){
                                                    control = (packet.getUByte(16)*256)+packet.getUByte(17);
                                                    System.out.printf("\n |-->Control: %04X", control);
                                                    System.out.printf("\n |-->Tipo: Información (Extendido)");
                                                    ns = packet.getUByte(16) & 0x000000FF;
                                                    ns = ns>>1;
                                                    System.out.printf("\n |-->N(S): %d", ns);
                                                    nr = packet.getUByte(17) & 0x000000FE;
                                                    nr = nr>>1;
                                                    System.out.printf("\n |-->N(R): %d", nr);
                                                }
                                                else{
                                                    control = packet.getUByte(16);
                                                    System.out.printf("\n |-->Control: %02X", control);
                                                    System.out.printf("\n |-->Tipo: Información");
                                                    ns = packet.getUByte(16) & 0x0000000F;
                                                    System.out.printf("\n |-->N(S): %d", ns>>1);
                                                    nr = packet.getUByte(16) & 0x000000E0;
                                                    System.out.printf("\n |-->N(R): %d", nr>>1);
                                                }
                                        
                                                if(pf == 1){
                                                    pf = packet.getUByte(15) & 0x00000001;
                                                    if(pf == 1){
                                                        System.out.printf("\n |-->P/F: Encendido (R)");
                                                    }
                                                    else{
                                                        System.out.printf("\n |-->P/F: Encendido (C)");
                                                    }
                                                }
                                                else{
                                                    System.out.printf("\n |-->P/F: Apagado");
                                                }
                                                
                                                break;
                                        case 1: if(longitud > 3){
                                                    control = (packet.getUByte(16)*256)+packet.getUByte(17);
                                                    System.out.printf("\n |-->Control: %04X", control);
                                                    System.out.printf("\n |-->Tipo: Secuencia (Extendido)");
                                                    codigo = packet.getUByte(16) & 0x0000000D;
                                                    switch(codigo){
                                                        case    1:  System.out.printf("\n |-->Codigo: RR");
                                                                    break; 
                                                        case    5:  System.out.printf("\n |-->Codigo: RNR");
                                                                    break;
                                                        case    9:  System.out.printf("\n |-->Codigo: REJ");
                                                                    break;
                                                        default:    System.out.printf("\n |-->Codigo: SRET");
                                                                    break;
                                                    }
                                                    nr = packet.getUByte(17) & 0x000000FE;
                                                    System.out.printf("\n |-->N(R): %d", nr>>1);
                                                }
                                                else{
                                                    control = packet.getUByte(16);
                                                    System.out.printf("\n |-->Control: %02X", control);
                                                    System.out.printf("\n |-->Tipo: Secuencia");
                                                    codigo = packet.getUByte(16) & 0x0000000D;
                                                    switch(codigo){
                                                        case    1:  System.out.printf("\n |-->Codigo: RR");
                                                                    break; 
                                                        case    5:  System.out.printf("\n |-->Codigo: RNR");
                                                                    break;
                                                        case    9:  System.out.printf("\n |-->Codigo: REJ");
                                                                    break;
                                                        default:    System.out.printf("\n |-->Codigo: SRET");
                                                                    break;
                                                    }
                                                    nr = packet.getUByte(16) & 0x000000E0;
                                                    nr = nr>>1;
                                                    System.out.printf("\n |-->N(R): %d", nr);
                                                }
                                        
                                                if(pf == 1){
                                                    pf = packet.getUByte(15) & 0x00000001;
                                                    if(pf == 1){
                                                        System.out.printf("\n |-->P/F: Encendido (R)");
                                                    }
                                                    else{
                                                        System.out.printf("\n |-->P/F: Encendido (C)");
                                                    }
                                                    
                                                }
                                                else{
                                                    System.out.printf("\n |-->P/F: Apagado");
                                                }
                                                
                                                break;
                                        case 3: control = packet.getUByte(16);
                                                System.out.printf("\n |-->Control: %02X", control);
                                                System.out.printf("\n |-->Tipo: Trama no numerada");
                                                codigo = control & 0x000000EF;
                                                switch(codigo){
                                                    case    111:    System.out.printf("\n |-->Codigo: SABME");
                                                                    break;
                                                    case    99:     System.out.printf("\n |-->Codigo: UA");
                                                                    break;
                                                    case    175:    System.out.printf("\n |-->Codigo: XID");
                                                                    break;
                                                    case    67:     System.out.printf("\n |-->Codigo: DISC");
                                                                    break;
                                                    case    3:      System.out.printf("\n |-->Codigo: UI");
                                                                    break;
                                                    case    143:    System.out.printf("\n |-->Codigo: RSET");
                                                                    break;
                                                    default:        System.out.printf("\n |-->Codigo: Sin idfentificar");
                                                                    break;
                                                }
                                                pf = control & 0x00000010;
                                                if(pf == 16){
                                                    pf = packet.getUByte(15) & 0x00000001;
                                                    if(pf == 1){
                                                        System.out.printf("\n |-->P/F: Encendido (R)");
                                                    }
                                                    else{
                                                        System.out.printf("\n |-->P/F: Encendido (C)");
                                                    }
                                                }
                                                else{
                                                    System.out.printf("\n |-->P/F: Apagado");
                                                }
                                                
                                                break;
                                        default: break;
                                    }
                                    
                                    
                                } else if(longitud>=1500){
                                    
                                    System.out.println("\n---->CAPA DE ENLACE DE DATOS\n |-->Trama Ethernet");
                                    System.out.printf(" |-->MAC Destino: %02X", packet.getUByte(0));
                                    
                                    for(int p = 1; p<=5; p++){
                                        System.out.printf(":%02X", packet.getUByte(p));
                                    }
                                    
                                    System.out.printf("\n |-->MAC Origen: %02X",packet.getUByte(6));
                                    
                                    for(int p = 7; p<=11; p++){
                                        System.out.printf(":%02X", packet.getUByte(p));
                                    }
                                    
                                    System.out.printf("\n |-->Tipo: %02X %02X",packet.getUByte(12), packet.getUByte(13));
                                    
                                    tipo = (packet.getUByte(12)*256) + packet.getUByte(13);
                                    
                                    switch(tipo){
                                       
                                        case    2048:   System.out.printf(" Internet Protocol version 4 (IPv4)");
                                                        System.out.printf("\n---->CAPA DE RED\n");
                                                        ver = packet.getUByte(14)>>4;
                                                        System.out.printf(" |-->Version: %d", ver);
                                                        te = packet.getUByte(14) & 0x0000000F;
                                                        System.out.printf("\n |-->Tamaño encabezado: %d (%d bytes)", te, te*4);
                                                        System.out.printf("\n |-->Tipo de servicio: %02X", packet.getUByte(15));
                                                        System.out.printf("\n |-->Longitud total del paquete: %d", ((packet.getUByte(16)<<8)+packet.getUByte(17)));
                                                        System.out.printf("\n |-->Identificación: %d", ((packet.getUByte(18)<<8)+packet.getUByte(19)));
                                                        System.out.printf("\n |-->Banderas: %02X", packet.getUByte(20));
                                                        System.out.printf("\n |-->Offset: %d", packet.getUByte(21));
                                                        System.out.printf("\n |-->Time to Live: %d", packet.getUByte(22));
                                                        System.out.printf("\n |-->Protocolo: %02X (%d)", packet.getUByte(23), packet.getUByte(23));
                                                        System.out.printf("\n |-->Checksum: %02X %02X", packet.getUByte(24), packet.getUByte(25));
                                                        System.out.printf("\n |-->Dirección origen: %d.%d.%d.%d", packet.getUByte(26), packet.getUByte(27), packet.getUByte(28), packet.getUByte(29));
                                                        System.out.printf("\n |-->Dirección destino: %d.%d.%d.%d", packet.getUByte(30), packet.getUByte(31), packet.getUByte(32), packet.getUByte(33));
                                                        if(packet.getUByte(23) == 6){
                                                            System.out.printf("\n---->CAPA DE TRANSPORTE (TCP)\n");
                                                            System.out.printf("\n |-->Puerto origen: %d", ((packet.getUByte(34)<<8)+packet.getUByte(35)));
                                                            System.out.printf("\n |-->Puerto destino: %d", ((packet.getUByte(36)<<8)+packet.getUByte(37)));
                                                            int sec = 0, acu = 0;
                                                            for(int s = 38; s <= 41; s++){
                                                                acu*=256;
                                                                sec+=packet.getUByte(s);
                                                            }
                                                            for(int s = 42; s <= 45; s++){
                                                                acu*=256;
                                                                acu+=packet.getUByte(s);
                                                            }
                                                            System.out.printf("\n |-->Número de secuencia: %d", sec);
                                                            System.out.printf("\n |-->Número de acuse: %d", acu);
                                                        }
                                                        else{
                                                            System.out.printf("\n---->CAPA DE TRANSPORTE (UDP)");
                                                            System.out.printf("\n |-->Puerto origen: %d", ((packet.getUByte(34)<<8)+packet.getUByte(35)));
                                                            System.out.printf("\n |-->Puerto destino: %d", ((packet.getUByte(36)<<8)+packet.getUByte(37)));
                                                            System.out.printf("\n |-->Longitud: %d", ((packet.getUByte(38)<<8)+packet.getUByte(39)));
                                                            System.out.printf("\n |-->Checksum: %02X %02X", packet.getUByte(40), packet.getUByte(41));
                                                        }
                                                        break;
                                        case    2054:   System.out.printf(" Address Resolution Protocol (ARP)");
                                                        System.out.printf("\n |-->Hardware: %02X %02X",packet.getUByte(14), packet.getUByte(15));
                                                        hw = (packet.getUByte(14)*256) + packet.getUByte(15);
                                                        switch(hw){
                                                            case    1:  System.out.printf(" Ethernet (10Mb)");
                                                                        break;
                                                            case    2:  System.out.printf(" Experimental Ethernet (3Mb)");
                                                                        break;
                                                            case    18: System.out.printf(" Fibre Channel");
                                                                        break;
                                                            case    20: System.out.printf(" Serial Line");
                                                                        break;
                                                            case    35: System.out.printf(" Pure IP");
                                                                        break;
                                                            default:    System.out.printf(" Hardware desconocido");
                                                                        break;
             
                                                        }
                                                        
                                                        System.out.printf("\n |-->Protocolo: %02X %02X",packet.getUByte(16), packet.getUByte(17));
                                                        proto = (packet.getUByte(16)*256) + packet.getUByte(17);
                                                        
                                                        switch(proto){
                                                            
                                                            case    2048:   System.out.printf(" Internet Protocol version 4 (IPv4)");
                                                                            break;
                                                            default:    System.out.printf(" Protocolo no identificado");
                                                                        break;
                                                        }
                                                        
                                                        System.out.printf("\n |-->Tamaño hardware: %02X (%d)",packet.getUByte(18), packet.getUByte(18));
                                                        System.out.printf("\n |-->Tamaño protocolo: %02X (%d)",packet.getUByte(19), packet.getUByte(19));
                                                        
                                                        System.out.printf("\n |-->Tipo operación: %02X %02X",packet.getUByte(20), packet.getUByte(21));
                                                        ope = (packet.getUByte(20)*256) + packet.getUByte(21);
                                                        
                                                        switch(ope){
                                                            case    1:  System.out.printf(" REQUEST");
                                                                        break;
                                                            case    2:  System.out.printf(" REPLY");
                                                                        break;
                                                        }
                                                        
                                                        System.out.printf("\n |-->MAC Origen: %02X",packet.getUByte(22));
                                    
                                                        for(int p = 23; p<=27; p++){
                                                            System.out.printf(":%02X", packet.getUByte(p));
                                                        }
                                                        
                                                        System.out.printf("\n |-->IP Origen: %d.%d.%d.%d", packet.getUByte(28), packet.getUByte(29), packet.getUByte(30), packet.getUByte(31));
                                                        System.out.printf("\n |-->MAC Destino: %02X",packet.getUByte(32));
                                    
                                                        for(int p = 33; p<=37; p++){
                                                            System.out.printf(":%02X", packet.getUByte(p));
                                                        }
                                                        
                                                        System.out.printf("\n |-->IP Destino: %d.%d.%d.%d", packet.getUByte(38), packet.getUByte(39), packet.getUByte(40), packet.getUByte(41));
                                                        
                                                        break;
                                        case    32923:  System.out.printf(" AppleTalk (Ethertalk)");
                                                        break;
                                        case    33011:  System.out.printf(" AppleTalk Address Resolution Protocol (AARP)");
                                                        break;
                                        case    34525:  System.out.printf(" Internet Protocol version 6 (IPv6)");
                                                        break;
                                        default:    System.out.printf(" Tipo desconocido");
                                                    break;
                                    }
                                }//else
                                
                                //System.out.println("\n\nEncabezado: "+ packet.toHexdump());
      

			}
		};


		/***************************************************************************
		 * Fourth we enter the loop and tell it to capture 10 packets. The loop
		 * method does a mapping of pcap.datalink() DLT value to JProtocol ID, which
		 * is needed by JScanner. The scanner scans the packet buffer and decodes
		 * the headers. The mapping is done automatically, although a variation on
		 * the loop method exists that allows the programmer to sepecify exactly
		 * which protocol ID to use as the data link type for this pcap interface.
		 **************************************************************************/
		
                pcap.loop(lo, jpacketHandler, " ");

		/***************************************************************************
		 * Last thing to do is close the pcap handle
		 **************************************************************************/
		pcap.close();
                }catch(IOException e){e.printStackTrace();}
	}
}
